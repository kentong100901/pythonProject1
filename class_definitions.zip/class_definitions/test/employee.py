# ***************************************************************
# Name : ProgramNameTong
# Author: Than Tong
# Created : * Course: CIS189
# Version: 1.0
# OS: Windows 11
# IDE: Python
# Copyright : This is my own original work
# based onspecifications issued by our instructor
# Description :
#           Input: ADD HERE XXX
#           Ouput: ADD HERE XXX
# Academic Honesty: I attest that this is my original work.
# I have not used unauthorized source code, either modified or
# unmodified. I have not given other fellow student(s) access
# to my program.
from datetime import datetime


class Employee:

    def __init__(self, last_name, first_name, address, phone_number, salaried, start_date, salary):
        # Private variables with double underscores
        self.__last_name = last_name
        self.__first_name = first_name
        self.__address = address
        self.__phone_number = str(phone_number)  # Converting phone number to string
        self.__salaried = salaried

        # Formatting salary as string with two decimal places
        self.__salary = '%.2f' % float(salary)

        # Converting start date to datetime object
        dateObj = datetime.strptime(start_date, '%m/%d/%Y')
        # Formatting start date back to string in 'mm/dd/yyyy' format
        self.__start_date = dateObj.strftime('%m/%d/%Y')

    def display(self):
        info = f'{self.__first_name} {self.__last_name}\n'
        info += f'{self.__address}\n'

        if self.__salaried:
            info += f'Salaried employee: ${self.__salary}/year\n'
            info += f'Start date: {self.__start_date}\n'
        else:
            info += f'Hourly employee: ${self.__salary}/hour\n'
            info += f'Start date: {self.__start_date}\n'

        return info


# Creating instances and displaying their information
E = Employee("Patel", "Sasha", "123 Main Street \nUrban, Iowa", "9082098121", True, '06/28/2019', 40000)
print(E.display())

E = Employee("Patel", "Sasha", "123 Main Street \nUrban, Iowa", "9082098121", False, '03/26/2022', 0)
print(E.display())
