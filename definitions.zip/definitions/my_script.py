# ***************************************************************
# Name : ProgramNameTong
# Author: Than Tong
# Created : * Course: CIS189
# Version: 1.0
# OS: Windows 11
# IDE: Python
# Copyright : This is my own original work
# based onspecifications issued by our instructor
# Description :
#           Input: ADD HERE XXX
#           Ouput: ADD HERE XXX
# Academic Honesty: I attest that this is my original work.
# I have not used unauthorized source code, either modified or
# unmodified. I have not given other fellow student(s) access
# to my program.
from definitions import greeting, message, print_dict, print_set

# Use the functions from the package
greeting()
message()

sample_dict = {'Organe': 100, 'Strawberry': 80, 'Apple': 90}
print_dict(sample_dict)

sample_set = {1, 2, 3, 4, 5}
print_set(sample_set)

